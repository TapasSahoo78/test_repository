<?php

namespace App\Console\Commands;

use App\Http\Resources\Api\BookingResource;
use App\Models\User\Booking;
use App\Models\User\User;
use App\Services\User\UserService;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
// use
use App\Traits\SendPushNotification;

class SendBooking extends Command
{
    use SendPushNotification;
    public function __construct(protected UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:send-booking';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';
    /**
     * Execute the console command.
     */
    public function handle()
    {
        $currentTimestamp = Carbon::now(); // Get the current timestamp
        // Retrieve scheduled bookings that are still active
        $currentDate = Carbon::now()->toDateString(); // Get the current date
        $bookingInfo = Booking::where(['is_accepted' => 1, 'type' => 'scheduled'])
            ->whereNull('driver_id')
            ->whereDate('scheduled_at', $currentDate) // Filter by current date
            ->orderBy('id', 'desc')
            ->take(1)
            ->get();
        Log::info("Found " . $bookingInfo . " ____scheduled bookings to process.");
        foreach ($bookingInfo as $booking) {
            Log::info("Found " . $booking . " ###scheduled bookings to process.");
            $scheduledTime = Carbon::parse($booking->scheduled_at);
            $thirtyMinutesBefore = $scheduledTime->copy()->subMinutes(30);
            Log::info("Found " . $scheduledTime . "=>>>>>>>>>>>>" . $scheduledTime->copy()->subMinutes(30) . " Check if the booking is within 30 minutes of the scheduled time");

            // Check if the booking is within 30 minutes of the scheduled time
            Log::info("Found " . $thirtyMinutesBefore . "----" . $currentTimestamp . "----" . $scheduledTime . "-----" . $currentTimestamp . " after 30 minutes");
            Log::info("Found (" . $thirtyMinutesBefore >= $currentTimestamp  && $scheduledTime < $currentTimestamp . " after 30 minutes");
            if ($thirtyMinutesBefore <= $currentTimestamp && $scheduledTime > $currentTimestamp) {
                // if ($thirtyMinutesBefore <= $currentTimestamp && $scheduledTime > $currentTimestamp) {

                // **************************User Notifaction*******************************************
                $userfcmToken = $booking->users->device_token;
                $notificationData = (object)[
                    'title' => 'Booking Reminder',
                    'body'  => 'You have a booking scheduled in 30 minutes nearby.',
                    'data' => new BookingResource($booking),
                    'image' => 'https://example.com/path/to/image.jpg',
                ];
                Log::info("Found " . $userfcmToken . "############################# userfcmToken.");
                // Send the push notification
                $this->sendNotification($notificationData, $userfcmToken);

                // ***********************Driver**********************************************
                $from_address = json_decode($booking->from_address, true);
                // Extract latitude and longitude
                $latitude = $from_address['lat'];
                $longitude = $from_address['long'];
                Log::info("Found " . $latitude . " and " . $longitude . " ###latitude longitude");
                // Find nearest online drivers within 10 km

                $nearbyDrivers = $this->getNearbyDrivers($latitude, $longitude, getSiteSetting("search_radius"));
                foreach ($nearbyDrivers as $driver) {
                    if ($driver->vehicles->first()->category->slug == $booking->bookingCategory->slug) {
                        Log::info("Found " . $driver . " ###sdriver details.");
                        if ($driver->is_online) {
                            $fcmToken = $driver->device_token;
                            $notificationData = (object)[
                                'body' => 'New Booking Have Arrived',
                                'title' => 'Booking Created',
                                'data' => new BookingResource($booking),
                                // 'data' => BookingResource::collection($booking),
                                'image' => 'https://example.com/path/to/image.jpg',
                            ];
                            Log::info("Found " . $userfcmToken . "############################# userfcmToken.");
                            // Send the push notification
                            $this->sendNotification($notificationData, $fcmToken);
                            // Log successful notification
                            Log::info("Notification sent to online driver (ID: {$driver->id}) for booking (ID: {$booking->id}).");
                        } else {
                            Log::info("Driver (ID: {$driver->id}) is not online, skipping notification.");
                        }
                    }
                }
            } else {
                Log::info("Booking ID {$booking->id} is not within the 30-minute window or already passed.");
            }
        }
    }

    private function getNearbyDrivers($lat, $lng, $distance)
    {
        $drivers = $this->userService->findUserByRole(['is_online' => true, 'is_active' => true], 'driver');
        return $drivers->filter(function ($driver) use ($lat, $lng, $distance) {
            $driverDistance = $this->calculateDistance($lat, $lng, $driver->latitude, $driver->longitude);
            return $driverDistance <= $distance;
        });
    }
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers
        // Convert degrees to radians
        $lat1 = deg2rad($lat1);
        $lon1 = deg2rad($lon1);
        $lat2 = deg2rad($lat2);
        $lon2 = deg2rad($lon2);
        // Haversine formula
        $dlat = $lat2 - $lat1;
        $dlon = $lon2 - $lon1;
        $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlon / 2) * sin($dlon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        // Calculate the distance
        return $earthRadius * $c;
    }
}
