<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Services\Coupon\CouponService;

class ExpireCoupon extends Command
{

    public function __construct(protected CouponService $couponService)
    {
        parent::__construct();
        $this->couponService = $couponService;
    }
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:expire-coupons';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check And Expire the coupons by date and time';

    /**
     * Execute the console command.
     */
    public function handle()
    {
    DB::beginTransaction();
        try {
        $count=0;
            $coupons = $this->couponService->listCoupons(['is_active' => true, 'is_expired' => true]);
            foreach ($coupons as $coupon) {
                if (strtotime($coupon->ended_at) < strtotime(date('Y-m-d H:i:s'))) {
                    $count++;
                    $coupon->update(['is_expired' => true]);
                    $this->success($coupon->name." has been expired.");
                }
            }
            if(!$count){
                $this->info("No coupon is expired");
            }else{
                DB::commit();
            }

        } catch (\Throwable $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $this->error("Something went wrong");
        }
    }
}
